# Problem 1
def remove_max(numbers):
      max_value=max(numbers)
      return[num for num in numbers if num!=max_value]
def remove_minimum(numbers):
      min_value=min(numbers)
      return[num for num in numbers if num != min_value]
def average_excluding_extremes(numbers):
      if len(numbers)<3:
        print("The list must contain at least 3 numbers.")
        return None
      without_max=remove_max(numbers)
      excluding_list=remove_minimum(without_max)
      average=sum(excluding_list)/len(excluding_list)
      return average 
print(average_excluding_extremes([5, 10, 15, 20, 25]))

# Problem 2
def element_wise_operation(list1,list2,operation):
      if len(list1)!=len(list2):
            print("Both lists must have the same length.")
      def element_operations(a,b,operation):
            if operation=='add':
                  return a+b
            elif operation=='substract':
                  return a-b
            elif operation=='multiply':
                  return a*b
            elif operation=='divide':
                  if b==0:
                        print('Dividation is not possible')
                  else:
                        return a/b
            else:
                  print(f"Unsupported operation: {operation}. Choose from 'add', 'subtract', 'multiply', 'divide'")
      result=[]
      for i in range(len(list1)):
            result.append(element_operations(list1[i],list2[i],operation))
      return result
print(element_wise_operation([1, 2, 3], [4, 5, 6], "add"))

# Problem 3
def longest_word(word_list):
      if not word_list:
            print('There is no words!')
      else:
            longest=""
            word_count=0
            for word in word_list:
                  if len(word)>word_count:
                        longest=word
                        word_count=len(word)
            return longest,word_count
print(longest_word(["apple", "banana", "cherry"]))

# Problem 5
def count_character_occurrence(word,letter):
      letter_count=0
      for char in word:
            if char==letter:
                  letter_count+=1
      return letter_count
print(count_character_occurrence("programming", "g"))

# Problem 6
def merge_and_deduplicate(list1,list2):
      new_list=set(list1+list2)
      list3=list(new_list)
      return list3
print(merge_and_deduplicate([1, 2, 3], [3, 4, 5]))
      
# Problem 7
def shift_elements(list, data2):
    for i in range(1, data2 + 1):
        list.insert(0, list[-i])  
    for i in range(data2):
        del list[-1] 
    print(list)
list = [1, 2, 3, 4, 5]
data2 = 2
shift_elements(list, data2)


# Problem 8
def count_words(sentence):
      word_count=0
      senten=sentence.split()
      for char in senten:
            word_count+=1
      return word_count
print(count_words("This is a test sentence."))

# Problem 9
def find_common_elements(list1,list2):
      list3=[]
      for i in list1:
            for j in list2:
                  if i==j:
                        list3.append(i)
      return list3
print(find_common_elements([1, 2, 3], [2, 3, 4]))

# Problem 10
def validate_email(email):
      for i in range(len(email)):
            if email[i]=="@":
                  for j in range(i+1,len(email)):
                        if email[j]==".":
                              return True
            else:
                  return False
print(validate_email("test123gmail.com"))

# Problem 11
def generate_series(start,end,step):
      list=[]
      for i in range(start,end,step):
            list.append(i)
      return list
print(generate_series(1, 10, 2))

# Problem 12
